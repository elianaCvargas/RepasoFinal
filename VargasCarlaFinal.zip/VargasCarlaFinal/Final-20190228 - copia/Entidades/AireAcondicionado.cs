﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class AireAcondicionado : Electrodomestico
    {
        private int frigorias;

        public AireAcondicionado()
        { }

        public AireAcondicionado(string marca, string modelo,  float precio, int frigorias)
            : base(marca,  modelo, precio)
        {
            this.frigorias = frigorias;
        }

        public int Frigorias {
            get { return this.frigorias; }
            set { this.frigorias = value; }
        }

        public override float CalcularPrecioFinal()
        {
            if (this.frigorias    > 4000)
            {
                float interes = base.Precio * 10 / 100;
                base.Precio = base.Precio + interes;
                return Precio;
            }
            else
            {
                return base.Precio;
            }
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Datos Base: {0}\n", base.Mostrar());
            sb.AppendFormat("Capacidad: {0}\n", this.frigorias);
            return sb.ToString();
        }

        public static bool operator ==(AireAcondicionado e1, AireAcondicionado e2)
        {
            if (e1.Marca == e2.Marca && e1.Modelo == e2.Modelo && e1.Precio == e2.Precio && e1.frigorias == e2.frigorias)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(AireAcondicionado e1, AireAcondicionado e2)
        {
            return !(e1 == e2);
        }

    }
}
