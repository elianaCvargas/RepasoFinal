﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Electrodomestico
    {
        private string marca;
        private string modelo;
        private float precio;

        public Electrodomestico()
        { }

        public Electrodomestico(string marca, string modelo, float precio)
            :this()
        {
            this.marca = marca;
            this.modelo = modelo;
            this.precio = precio;
        }

        public string Marca {
            get { return this.marca; }
            set { this.marca = value; }
        }
        public string Modelo
        {
            get { return this.modelo; }
            set { this.modelo = value; }
        }
        public float Precio
        {
            get { return this.precio; }
            set { this.precio = value; }
        }

        public abstract float CalcularPrecioFinal();    

        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Marca: {0}\n", this.marca);
            sb.AppendFormat("Modelo: {0}\n", this.modelo);
            sb.AppendFormat("Precio: {0}\n", this.precio.ToString());

            return sb.ToString();
        }

        public static bool operator ==(Electrodomestico e1, Electrodomestico e2)
        {
            if (e1.marca == e2.marca && e1.modelo == e2.modelo && e1.precio == e2.precio)
            {
                return true; 
            }
            return false;
        }
        public static bool operator !=(Electrodomestico e1, Electrodomestico e2)
        {
            return !(e1 == e2);
        }

       
    }
}
