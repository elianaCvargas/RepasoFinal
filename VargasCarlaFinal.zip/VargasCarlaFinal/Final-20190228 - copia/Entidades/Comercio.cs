﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoMensaje(string mensaje);
    
    
    public class Comercio
    {
        private List<Electrodomestico> electrodomesticos;
        private string nombre;

        private Comercio()
        {
            this.electrodomesticos = new List<Electrodomestico>();
        }

        public Comercio(string nombre)
            :this()
        {
            this.nombre = nombre;
        }

        public List<Electrodomestico> Electrodomesticos {
            get { return this.Electrodomesticos; }
            set { this.Electrodomesticos = value; }
        }

        public float CalcularValorTotal()
        {
            float precioTotal = 0; 
            foreach (var item in this.electrodomesticos)
            {
                precioTotal += item.Precio;
            }
            return precioTotal;
        }

        public static explicit operator String(Comercio c)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in c.electrodomesticos)
            {
                sb.AppendFormat("Nombre: {0}\n", c.nombre);
                sb.AppendFormat("electrodomesticos: {0}\n", item.Mostrar());
            }
            return sb.ToString();
        }

        public static bool operator ==(Comercio c, Electrodomestico e)
        {
            if ( c.electrodomesticos.Contains(e))
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(Comercio c, Electrodomestico e)
        {
            return !(c == e);
        }
        public static Comercio operator +(Comercio c, Electrodomestico e)
        {
            if (c != e)
            {
                c.electrodomesticos.Add(e);
                c.Informar.Invoke("Se agregó el electrodoméstico.");
                return c; 
            }
            else
            {
                c.Informar.Invoke("El electrodoméstico ya fue agregado con anterioridad.");
                throw new ElectrodomesticoException("Electrodoméstico duplicado");
            }
            
        }

        //evento Informar:delegafdo  Mensaje
        public event DelegadoMensaje Informar;
    }
}
