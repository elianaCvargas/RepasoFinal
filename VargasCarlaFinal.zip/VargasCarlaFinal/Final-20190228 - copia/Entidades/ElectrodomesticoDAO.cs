﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ElectrodomesticoDAO
    {
        private static SqlConnection conexion;
        private static SqlCommand comando;

        static ProductoDAO()
        {
            conexion = new SqlConnection(Properties.Settings.Default.ConnectionString);
            comando = new SqlCommand();
            comando.CommandType = CommandType.Text;
            comando.Connection = conexion;
        }


        public static bool GuardarProducto(Producto producto)
        {
            ProductoA pA;
            ProductoB pB;
            string strQuery = "";
            if (producto is ProductoA)
            {
                pA = (ProductoA)producto;
                strQuery = "INSERT INTO Productos(Diametro,Material, Descripcion) VALUES ('" + pA.Diametro.ToString() + "','" + pA.Material.ToString() + "','" + pA.Descripcion.ToString() + "')";
            }
            else
            {
                pB = (ProductoB)producto;
                strQuery = "INSERT INTO Productos(Alto, Ancho, Largo, Descripcion) VALUES ('" + pB.Alto.ToString() + "','" + pB.Ancho.ToString() + "','" + pB.Largo.ToString() + "','" + pB.Descripcion.ToString() + "')";
            }

            return ProductoDAO.MiMetodoExecuteNonQuery(strQuery);
        }

        public List<Producto> Leer()
        {
            List<Producto> productos = new List<Producto>();
            ProductoA pA;
            ProductoB pB;
            comando.CommandText = "SELECT * FROM Productos";
            conexion.Open();
            SqlDataReader oDr = comando.ExecuteReader();

            while (oDr.Read())
            {
                if (oDr["Diametro"] != null && oDr["Material"] != null && oDr["Diametro"].ToString() != "")
                {
                    var diam = oDr["Diametro"].ToString();
                    short diametro = short.Parse(diam);
                    string mat = oDr["Material"].ToString();
                    Material material;
                    Enum.TryParse<Material>(mat, out material);
                    pA = new ProductoA(oDr["Descripcion"].ToString(), diametro, material);
                    productos.Add(pA);
                }
                if (oDr["Alto"] != null && oDr["Largo"] != null && oDr["Ancho"] != null && oDr["Alto"].ToString() != "")
                {
                    var alto = oDr["Alto"].ToString();
                    short altoS = short.Parse(alto);
                    var ancho = oDr["Ancho"].ToString();
                    short anchoS = short.Parse(alto);
                    var largo = oDr["Largo"].ToString();
                    short largoS = short.Parse(alto);
                    pB = new ProductoB(oDr["Descripcion"].ToString(), largoS, anchoS, altoS);
                    productos.Add(pB);
                }
            }
            conexion.Close();
            return productos;
        }

        public bool LeerPorID()
        {
            return false;
        }

        //public bool Modificar(Persona p)
        //{
        //    StringBuilder strQuery = new StringBuilder();
        //    strQuery.AppendFormat("UPDATE Persona SET Nombre = '{0}'", p.Nombre);
        //    strQuery.AppendFormat(", Apellido = '{0}'", p.Apellido);
        //    strQuery.AppendFormat("WHERE ID = {0}", p.Id);

        //    return PersonaDAO.MiMetodoExecuteNonQuery(strQuery.ToString());
        //}

        //public bool Borrar(Persona p)
        //{
        //    string strQuery = "DELETE FROM Persona WHERE ID = " + p.Id;

        //    return PersonaDAO.MiMetodoExecuteNonQuery(strQuery);
        //}

        private static bool MiMetodoExecuteNonQuery(string strQuery)
        {
            bool retorno = false;
            try
            {
                comando.CommandText = strQuery;
                conexion.Open();
                comando.ExecuteNonQuery();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                    conexion.Close();
            }

            return retorno;
        }
    }
}
