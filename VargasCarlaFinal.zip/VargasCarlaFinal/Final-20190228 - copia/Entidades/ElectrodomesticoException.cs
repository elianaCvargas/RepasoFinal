﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ElectrodomesticoException :Exception
    {
        public ElectrodomesticoException()
        {
        }

        public ElectrodomesticoException(string message)
            : base(message)
        {
        }

        public ElectrodomesticoException(string message, Exception e)
            : base(message, e)
        {
        }
    }
}
