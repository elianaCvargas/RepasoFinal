CREATE TABLE [dbo].[Electrodomesticos](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[marca] [varchar](50) NOT NULL,
	[modelo] [varchar](50) NOT NULL,
	[precio] [varchar](50) NOT NULL,
	[capacidad] [varchar](50) NULL,
	[frigorias] [varchar](50) NULL,
	[tipo] [varchar](50) NOT NULL
) ON [PRIMARY]
