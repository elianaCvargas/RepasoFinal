﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForms
{
    public partial class FormComercio : Form
    {
        Comercio comercio;

        public FormComercio()
        {
            InitializeComponent();
            comercio = new Comercio("Comercio UTN");
            string[] items = new string[] { "Aire", "Lavarropas" };
            this.cmbTipo.DataSource = items;
            this.cmbTipo.SelectedIndex = 0;
            this.cmbTipo.DropDownStyle = ComboBoxStyle.DropDownList;
            this.txtFrigorias.Enabled = true;
            this.txtCapacidad.Enabled = false;
        }

        private void FormComercio_Load(object sender, EventArgs e)
        {
            comercio.Informar += MostrarMensaje;
            List<Electrodomestico> lista = ElectrodomesticoDAO.Leer("Electrodomesticos");
            foreach (var item in lista)
            {
                this.rtbMostrar.Text = item.Mostrar();
            }
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            AireAcondicionado aire ;
            Lavarropas lava;
            float precio = float.Parse(this.txtPrecio.Text);

            if (this.cmbTipo.SelectedValue is "Aire")
            {
                int frigoria = int.Parse(this.txtFrigorias.Text);
                aire = new AireAcondicionado(this.txtMarca.Text, this.lblModelo.Text,precio ,frigoria );
                //this.comercio.Electrodomesticos = new List<Electrodomestico>();
                try
                {
                    this.comercio += aire;
                    ElectrodomesticoDAO.GuardarProducto("Electrodomesticos", aire);
                }
                catch (Exception u)
                {

                    throw new ElectrodomesticoException("Ocurrió un error al agregar el electrodoméstico");
                }
               
            }
            
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
           

           

        }

        private void cmbTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cmbTipo.SelectedIndex == 0)
            {
                this.txtFrigorias.Enabled = true;
                this.txtCapacidad.Enabled = false;
            }
            else
            {
                this.txtFrigorias.Enabled = false;
                this.txtCapacidad.Enabled = true;
            }
        }

        public void MostrarMensaje(string mensaje)
        {
            MessageBox.Show(mensaje);
        }

        private void rtbMostrar_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

