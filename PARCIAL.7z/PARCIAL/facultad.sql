-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-11-2019 a las 19:36:18
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `facultad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accesos`
--

CREATE TABLE `accesos` (
  `id` int(11) NOT NULL,
  `legajo` int(11) NOT NULL,
  `email` varchar(50) COLLATE ucs2_spanish2_ci NOT NULL,
  `clave` varchar(100) COLLATE ucs2_spanish2_ci NOT NULL,
  `fechaIngreso` datetime NOT NULL,
  `fechaEgreso` datetime DEFAULT NULL,
  `field list` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Volcado de datos para la tabla `accesos`
--

INSERT INTO `accesos` (`id`, `legajo`, `email`, `clave`, `fechaIngreso`, `fechaEgreso`, `field list`, `updated_at`, `created_at`) VALUES
(5, 100, 'email@dominio.com.ar', 'email@dominio.com.ar', '2019-11-25 16:10:20', NULL, 0, '2019-11-25', '2019-11-25'),
(6, 100, 'email@dominio.com.ar', 'email@dominio.com.ar', '2019-11-25 16:18:52', NULL, 0, '2019-11-25', '2019-11-25'),
(7, 100, 'email@dominio.com.ar', 'email@dominio.com.ar', '2019-11-25 16:43:05', NULL, 0, '2019-11-25', '2019-11-25'),
(8, 100, 'email@dominio.com.ar', 'email@dominio.com.ar', '2019-11-25 16:43:54', NULL, 0, '2019-11-25', '2019-11-25'),
(9, 100, 'email@dominio.com.ar', 'email@dominio.com.ar', '2019-11-25 16:51:09', '2019-11-25 18:27:46', 0, '2019-11-25', '2019-11-25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `email` varchar(50) COLLATE ucs2_spanish2_ci NOT NULL,
  `clave` varchar(100) COLLATE ucs2_spanish2_ci NOT NULL,
  `tipo` varchar(10) COLLATE ucs2_spanish2_ci NOT NULL,
  `legajo` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `clave`, `tipo`, `legajo`, `updated_at`, `created_at`) VALUES
(1, 'email@dominio.com.ar', '1234', 'estudiante', 338, '2019-11-22', '2019-11-22'),
(4, 'email@dominio.com.ar', '12345', 'estudiante', 789, '2019-11-23', '2019-11-23'),
(5, 'email@dominio.com.ar', '12345', 'estudiante', 7891, '2019-11-23', '2019-11-23'),
(6, 'email@dominio.com.ar', '1234', 'estudiante', -1, '2019-11-23', '2019-11-23'),
(9, 'email@dominio.com.ar', '1234', 'estudiante', 1, '2019-11-23', '2019-11-23'),
(11, 'email@dominio.com.ar', '1234', 'estudiante', -11, '2019-11-23', '2019-11-23'),
(12, 'email@dominio.com.ar', '1234', 'estudiante', 11, '2019-11-23', '2019-11-23'),
(13, 'email@dominio.com.ar', '1234', 'estudiante', 1005, '2019-11-23', '2019-11-23'),
(14, 'email@dominio.com.ar', '1234', 'estudiante', 100, '2019-11-24', '2019-11-24'),
(16, 'email@dominio.com.ar', 'yRtyKvulL4', 'estudiante', 101, '2019-11-24', '2019-11-24'),
(17, 'geral@mesa.com', '789', 'alu', 321, '2019-11-25', '2019-11-25'),
(19, 'geral@mesa.com', 'XXT0uMV6zx', 'alu', 323, '2019-11-25', '2019-11-25'),
(20, 'geral@mesa.com', 'o6W8dcoMuhzPuLT2whIWbGHnQC2UE4fNK3qmsmt3Kg4=', 'alu', 4, '2019-11-25', '2019-11-25'),
(22, 'geral@mesa.com', 'k1zpZh0qcBpMkARxKcXXP/hMmCP5UA/Mh98h3upl6B4=', 'a', 2, '2019-11-25', '2019-11-25');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accesos`
--
ALTER TABLE `accesos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `legajo` (`legajo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `accesos`
--
ALTER TABLE `accesos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
