<?php
namespace App\Models\ORM;
use App\Models\ORM\usuario;
use App\Models\IApiControler;
use App\Models\cryptor;
use App\archivero;

include_once __DIR__ . '/usuario.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';
include_once __DIR__ . '/../../archivero.php';
include_once __DIR__ . '../../modelAPI/cryptor.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class usuarioController implements IApiControler 
{
 	public function Beinvenida($request, $response, $args) {
      $response->getBody()->write("GET => Bienvenido!!! ,a UTN FRA SlimFramework");
    
    return $response;
    }
    
     public function TraerTodos($request, $response, $args) {
       	//return usuario::all()->toJson();
        $todosLosUsuarios = usuario::all();
        $newResponse = $response->withJson($todosLosUsuarios, 200);  
        return $newResponse;
    }

    public function TraerUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
    	return $newResponse;
    }
   
    public function CargarUno($request, $response, $args) {
      $arrayDeParametros = $request->getParsedBody();
      $clave = $arrayDeParametros["clave"];
     
      //comento metodo que funciona para encriptar
      // $cryptorData = new Cryptor();
      // $encriptedKey = $cryptorData->encrypt($clave, 'e');

      $attributes = [
        "email" => $arrayDeParametros["email"],
        "clave" => $arrayDeParametros["clave"],
        "legajo" => $arrayDeParametros["legajo"]
      ];
      
      if (Usuario::validate($attributes))
      {
        //if(usuarioLoggeado($attributes)->legajo == $attributes)
        $attributes["clave"] = $clave;
        Usuario::create($attributes);
        $this->GuardarImagen($request);
         
        $newResponse = $response->withJson("Alumno cargado con éxito", 200); 
        return $newResponse;
      }
    }


    public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
    public function ModificarUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
		return 	$newResponse;
    }

    public function GuardarImagen($request)
    {
      $archivos = $request->getUploadedFiles();   
      if(Usuario::validateImage($archivos))
      {
        $imagen1 = $archivos['imagen1'];
        $imagen2 = $archivos['imagen2'];
        $fullName1 = $imagen1->getClientFilename();
        $fullName2 = $imagen2->getClientFilename();
        Archivero::GuargarImagen($fullName1, $imagen1);
        Archivero::GuargarImagen($fullName2, $imagen2);
      }     
      else
      {
          echo "cant save image";
      }
    }

    public function usuarioLoggeado($attributes)
    {
        
        $user = Acceso::where('clave', $attributes["clave"])
        ->where('email', $attributes["email"])
        ->where('legajo', $attributes["legajo"])->first();
        
        return $user;
    }
  
}