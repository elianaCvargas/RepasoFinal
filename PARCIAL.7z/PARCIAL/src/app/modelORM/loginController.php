<?php
namespace App\Models\ORM;
use App\Models\AutentificadorJWT;
use App\Models\ORM\usuario;
use App\Managers\ExceptionManager;
use App\Models\cryptor;

include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';
include_once __DIR__ . '/usuario.php';
include_once __DIR__ . '../../managers/ExceptionManager.php';
include_once __DIR__ . '../../modelAPI/cryptor.php';
class loginController 
{
    public function login($request, $response, $args)
    {
        $arrayDeParametros = $request->getParsedBody();
        $datos = array(
            'clave' => $arrayDeParametros["clave"],
            'email' => $arrayDeParametros["email"], 
            'legajo' => $arrayDeParametros["legajo"]);
            
        //$cryptorData = new Cryptor();
        $user = Usuario::where('clave', $arrayDeParametros["clave"])
        ->where('email', $arrayDeParametros["email"])
        ->where('legajo', $arrayDeParametros["legajo"])->first();

        //var_dump($user);
       //->where('clave', $cryptorData->decrypt($user->clave, 'e'))->first();

       
        // $cryptorData = new Cryptor();
        // foreach(
        //     Usuario::where('email', $arrayDeParametros["email"])
        //     ->where('legajo', $arrayDeParametros["legajo"])
        //     as $item
        // )
        // {
        //     var_dump($item->clave);
        //     if($cryptorData->decrypt($item->legajo, 'e') == $arrayDeParametros["legajo"])
        //     {
        //         var_dump($cryptorData->decrypt($item->legajo, 'e'));
        //     }
        //     var_dump($item->legajo);
        // }


       

        if($user != null)
        {
            $token= AutentificadorJWT::CrearToken($datos);
            $newResponse = $response->withJson($token, 200); 
            return $newResponse;  
        }
        else 
        {
            return  ExceptionManager::MostrarExcepcion("No existe el usuario.");
        }
    }
}
?>