<?php
namespace App\Models\ORM;
use App\Models\AutentificadorJWT;
use App\Models\ORM\acceso;
use \DateTime;
use App\Models\ORM\usuario;
use App\Managers\ExceptionManager;

include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';
include_once __DIR__ . '/acceso.php';
include_once __DIR__ . '/usuario.php';
include_once __DIR__ . '../../managers/ExceptionManager.php';

class accesoController
{
    public function ingresar($request, $response, $args)
    {        
        $token=null;
        $arrayConToken = $request->getHeader('token');
        
        if($arrayConToken)
        {
            $token=$arrayConToken[0];
        }
        //var_dump($token);
        if  ($token)
        {
             AutentificadorJWT::VerificarToken($token);
             $dataToken = AutentificadorJWT::ObtenerData($token);
             //var_dump($dataToken->email);
             $ahora = new \DateTime;
             $ahora->format('Y-m-d H:i:s');
             $attributes = [
                "email" => $dataToken->email,
                "clave" => $dataToken->clave,
                "fechaIngreso" => $ahora,
                "fechaEgreso" => null,
                "legajo" => $dataToken->legajo
              ];

            if($this->HayUsuarioLoggeado($attributes))
            {
                return  ExceptionManager::MostrarExcepcion("El usuario se encuentra loggeado.");
            }

            Acceso::create($attributes);
            return "Acceso generado";
        }
        else
        {
             $token=" no psasste el token";
      
        }
        
        return $token;
    }

    public function egresar($request, $response, $args)
    {        
        $token=null;
        $arrayConToken = $request->getHeader('token');
        
        if($arrayConToken)
        {
            $token=$arrayConToken[0];
        }
        if  ($token)
        {
             AutentificadorJWT::VerificarToken($token);
             $dataToken = AutentificadorJWT::ObtenerData($token);


             $ahora = new \DateTime;
             $ahora->format('Y-m-d H:i:s');
             $attributes = [
                "email" => $dataToken->email,
                "clave" => $dataToken->clave,
                "legajo" => $dataToken->legajo
              ];

              //busco usuario loggueado
            $accesoUser = $this->usuarioLoggeado($attributes);
              
            
            if($this->HayUsuarioLoggeado($attributes) 
            && $accesoUser->fechaEgreso == null)
            {
                $accesoUser->update(['fechaEgreso' => $ahora]);
                return $response->withJson("usuario desloggeado", 200);
            }
            return  ExceptionManager::MostrarExcepcion("El usuario no se encuentra loggeado");
        }
        else
        {
             $token=" no psasste el token";
      
        }
        
        return $token;
    }

    public function MostrarUsuarioLoggeado($request, $response, $args)
    {
        // var_dump($request);
        $dataToken = $this->autencticarToken($request);

             $attributes = [
                "email" => $dataToken->email,
                "clave" => $dataToken->clave,
                "legajo" => $dataToken->legajo
              ];

              $user = Acceso::where('clave', $attributes["clave"])
                ->where('email', $attributes["email"])
                ->where('legajo', $attributes["legajo"])
                ->orderBy('fechaIngreso','desc');
            foreach($user as $item)
            {
                echo "Usuario: email".$user->email.", Legajo: ".$user->legajo.", FechaIngreso: ".$user->fechaIngreso;
            }
       
    }

    public function HayUsuarioLoggeado($attributes)
    {
        $user = $this->usuarioLoggeado($attributes);
        if($user != null || $user != "")
        {
            if($user->fechaIngreso != null && $user->fechaEgreso == null)
            {
                return true;
            }
        }
        
        
        return false;
    }

    public function usuarioLoggeado($attributes)
    {
        
        $user = Acceso::where('clave', $attributes["clave"])
        ->where('email', $attributes["email"])
        ->where('legajo', $attributes["legajo"])
        ->orderBy('fechaIngreso','desc')->first();
        //var_dump($user);
        return $user;
    }

    public function autencticarToken($request)
    {

        // $token=null;
        // $arrayConToken = $request->getHeader('token');
        // if($arrayConToken)
        // {
        //     $token=$arrayConToken[0];
        // }
        // //var_dump($token);
        // if  ($token)
        // {
        //      AutentificadorJWT::VerificarToken($token);
        //      $dataToken = AutentificadorJWT::ObtenerData($token);
        // }
        // else
        // {
        //     $token=" no psasste el token";
          
        // }
            
        // return $token;
echo "in";
    }



}

?>