<?php

namespace App\Models;
use \Slim\Interfaces\CryptInterface;

class Cryptor 
{
    function encrypt( $string, $action = 'e' ) {
        // you may change these values to your own
        $secret_key = 'my_simple_secret_key';
        $secret_iv = 'my_simple_secret_iv';
    
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    
        if( $action == 'e' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'd' ){
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        }
    
        return $output;
    }

    function decrypt( $string, $action = 'd' ) {
        // you may change these values to your own
        $secret_key = 'my_simple_secret_key';
        $secret_iv = 'my_simple_secret_iv';
    
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
    
        if( $action == 'e' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'd' ){
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        }
    
        return $output;
    }

    protected function getHmac($data)
    {
        return hash_hmac('sha256', (string)$data, $this->key);
    }

    public function validateKeyLength($key, $module)
    {
        $keySize = strlen($key);
        $keySizeMin = 1;
        $keySizeMax = mcrypt_enc_get_key_size($module);
        $validKeySizes = mcrypt_enc_get_supported_key_sizes($module);
        if ($validKeySizes) {
            if (!in_array($keySize, $validKeySizes)) {
                throw new \InvalidArgumentException('Encryption key length must be one of: ' . implode(', ', $validKeySizes));
            }
        } else {
            if ($keySize < $keySizeMin || $keySize > $keySizeMax) {
                throw new \InvalidArgumentException(sprintf(
                    'Encryption key length must be between %s and %s, inclusive',
                    $keySizeMin,
                    $keySizeMax
                ));
            }
        }
    }
    /**
     * Check the mcrypt PHP extension is loaded
     * @throws \RuntimeException If the mcrypt PHP extension is missing
     */
    protected function checkRequirements()
    {
        if (extension_loaded('mcrypt') === false) {
            throw new \RuntimeException(sprintf(
                'The PHP mcrypt extension must be installed to use the %s encryption class.',
                __CLASS__
            ));
        }
    }
    /**
     * Throw an exception based on a provided exit code
     * @param  mixed  $code
     * @param  string $function
     * @throws \RuntimeException If there was a memory allocation problem
     * @throws \RuntimeException If there was an incorrect key length specified
     * @throws \RuntimeException If an unknown error occured
     */
    protected function throwInitError($code, $function)
    {
        switch ($code) {
            case -4:
                throw new \RuntimeException(sprintf(
                    'There was a memory allocation problem while calling %s::%s',
                    __CLASS__,
                    $function
                ));
                break;
            case -3:
                throw new \RuntimeException(sprintf(
                    'An incorrect encryption key length was used while calling %s::%s',
                    __CLASS__,
                    $function
                ));
                break;
            default:
                if (is_integer($code) && $code < 0) {
                    throw new \RuntimeException(sprintf(
                        'An unknown error was caught while calling %s::%s',
                        __CLASS__,
                        $function
                    ));
                }
                break;
        }
    }
}