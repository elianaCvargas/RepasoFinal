﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Threading;

namespace VistaForm
{
    public partial class FormPedido : Form
    {
        private Pedido pedido = new Pedido();
        Thread hilo;

        public FormPedido()
        {
            InitializeComponent();
            
            this.CargarProductosTerminados();

        }

        private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (this.hilo.IsAlive)
                this.hilo.Abort();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            cmbMaterial.DataSource = Enum.GetValues(typeof(Material));
        }

        void TotalizarProductosTerminados(object sender, EventArgs e)
        {
            if (this.lblContadorProductos.InvokeRequired)
            {
                this.lblContadorProductos.BeginInvoke((MethodInvoker)delegate () {
                    this.lblContadorProductos.Text = (int.Parse(lblContadorProductos.Text) + 1).ToString();
                });
            }
            else
                lblContadorProductos.Text = (int.Parse(lblContadorProductos.Text) + 1).ToString();
        }

        void AgregarProductoTerminado(object sender, EventArgs e)
        {
            if (this.lstTerminados.InvokeRequired)
            {
                this.lstTerminados.BeginInvoke((MethodInvoker)delegate () {
                    this.lstTerminados.Items.Add(((Producto)sender).Mostrar());
                });
            }
            else
                this.lstTerminados.Items.Add(((Producto)sender).Mostrar());
        }

        void CargarProductosTerminados()
        {
            ProductoDAO pDao = new ProductoDAO();
            List<Producto>listaTerminados =  pDao.Leer();
            foreach (var item in listaTerminados)
            {
                this.lstTerminados.Items.Add(item.Mostrar());
            }
            TxtFile txtFile = new TxtFile("TestFile");
            this.lstTerminados.Items.Add(txtFile.Leer("TestFile.txt"));
            this.lblContadorProductos.Text = listaTerminados.Count.ToString();
           

        }

        private void btnAgregarA_Click(object sender, EventArgs e)
        {
            Material material;
            Enum.TryParse<Material>(cmbMaterial.SelectedValue.ToString(), out material);
            //Código alumno
            Material materialA = (Material)this.cmbMaterial.SelectedValue;
            short diametroA = (short)this.nudDiametro.Value;
            ProductoA pA = new ProductoA(this.txtDescripcionA.Text, diametroA, material);
            pA.InformarProductoTerminado += TotalizarProductosTerminados;
            pA.InformarProductoTerminado += AgregarProductoTerminado;
            this.pedido += pA;
            TxtFile archivoTexto = new TxtFile("TestFile.txt");
            archivoTexto.Guardar(pA);
        }

        private void btnAgregarB_Click(object sender, EventArgs e)
        {
            //Código alumno
            ProductoB pB = new ProductoB(this.txtDescripcionB.Text, (short)this.nudLargo.Value, (short)this.nudAncho.Value, (short)this.nudAlto.Value);
            pB.InformarProductoTerminado += TotalizarProductosTerminados;
            pB.InformarProductoTerminado += AgregarProductoTerminado;         
            this.pedido.Productos.Add(pB);
            this.lstTerminados.Items.Add(pedido[1].Mostrar());
        }

        private void btnConfirmarPedido_Click(object sender, EventArgs e)
        {
            this.hilo = new Thread(pedido.FabricarPedido);
            this.hilo.Start();
        }

        private void lstTerminados_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblContadorProductos_Click(object sender, EventArgs e)
        {

        }
    }
}
