﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{

    public class ProductoA : Producto
    {
        private short diametro;
        private Material material;

        public short Diametro
        {
            get { return this.diametro; }
            set { this.diametro = value; }
        }
        public Material Material{
            get { return this.material; }
            set {
                try
                {
                    if (ValidarDimensiones())
                    {
                        material = value;
                    }
                }
                catch (Exception)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("No se puede fabricar una pieza de {0} y diámetro de {1} centímetros.", material.ToString(), diametro.ToString());
                    throw new ProductoException(sb.ToString());
                }
            }
        }

        public ProductoA()
        {
        }

        public ProductoA(string descripcion, short diametro, Material material)
            :base(descripcion)
        {
            this.diametro = diametro;
            this.Material = material;
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Descripción: {0}\n", base.Descripcion);
            sb.AppendFormat("Diametro: {0}\n", this.diametro.ToString());
            sb.AppendFormat("Material: {0}\n", this.material.ToString());
            return sb.ToString();
        }

        public override bool ValidarDimensiones()
        {
            bool retorno = false;
            switch (material)
            {
                case Material.Plastico:
                    retorno = true;
                    break;
                case Material.Aluminio:
                    if (diametro <= 10 && diametro > 0)
                    {
                        retorno = true;
                    }
                    break;
                case Material.Caucho:
                    if (diametro <= 15 && diametro > 0)
                    {
                        retorno = true;
                    }
                    break;
                default:
                    retorno = false;
                    break;
            }
            return retorno;
        }
    }
}
