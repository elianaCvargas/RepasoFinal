﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ProductoException : Exception
    {
        public ProductoException()
        {
        }

        public ProductoException(string message)
            : base(message)
        {
        }

        public ProductoException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
