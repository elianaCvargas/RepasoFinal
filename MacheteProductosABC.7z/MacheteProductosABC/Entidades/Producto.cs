﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{

    public abstract class Producto
    {
        private string descripcion;

        public Producto() { }

        public Producto(string descripcion)
            :this()
        {
            this.descripcion = descripcion;
        }

        public string Descripcion {
            get { return this.descripcion; }
            set { this.descripcion = value; }
        }

        public void Elaborar()
        {
            ProductoDAO.GuardarProducto(this);
            this.InformarProductoTerminado.Invoke(this, null);
        }

        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Descripción: {0}\n", descripcion);
            return sb.ToString();
        }

        public abstract bool ValidarDimensiones();
       
        //el delegado tiene la firma parecida al metodo al que se invocará
        public delegate void ProductoTerminado(object sender, EventArgs e);
       
        //el evento es siempre del tipo del delegado
        public event ProductoTerminado InformarProductoTerminado;

        /// <summary>
        /// Override del metodo Equals
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>true si ambos paquetes son iguales, false si no lo son</returns>  
        //public override bool Equals(object obj)
        //{
        //    if (!(obj is ProductoA))
        //        return false;
        //    return (ProductoA)obj;
        //}


    }
}
