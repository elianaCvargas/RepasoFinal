﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ProductoB : Producto
    {
        private short alto;
        private short ancho;
        private short largo;

        public ProductoB(string descripcion, short largo, short ancho, short alto)
            :base(descripcion)
        {
            this.Alto = alto;
            this.Ancho = ancho;
            this.Largo = largo;
        }

        public short Alto
        {
            get { return this.alto; }
            set
            {
                if (ValidarDimensiones())
                {
                    this.alto = value;
                }
            }
        }

        public short Ancho
        {
            get { return this.ancho; }
            set
            {
                if (ValidarDimensiones())
                {
                    this.ancho = value;
                }
            }
        }

        public short Largo
        {
            get { return this.largo; }
            set
            {
                if (ValidarDimensiones())
                {
                    this.largo = value;
                }
            }
        }

        public int CalcularVolumen()
        {
            return this.alto * this.ancho * this.largo;
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Descripción: {0}\n", base.Descripcion);
            sb.AppendFormat("Alto: {0}\n", this.alto.ToString());
            sb.AppendFormat("Ancho: {0}\n", this.Ancho.ToString());
            sb.AppendFormat("Largo: {0}\n", this.largo.ToString());
            sb.AppendFormat("Volumen: {0}\n", this.CalcularVolumen().ToString());
            return sb.ToString();
        }

        public override bool ValidarDimensiones()
        {
            if (largo + ancho + alto <= 100)
            {
                return true; 
            }
            return false;
        }

        public static explicit operator int(ProductoB productoB)
        {
            return productoB.CalcularVolumen();
        }

        //public override string ToString()
        //{
        //    return String.Format("Turno Nº{0}: {2}, {1}", Turno, this.apellido, this.nombre);
        //}
    }
}
