﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TxtFile : IArchivo<string, Producto>
    {
        private string pathArchivos;

        public TxtFile(string path)
        {
            this.pathArchivos = path;
        }

        //public override void MostrarArchivos()
        //{
        //    throw new NotImplementedException("No se puede mostrar");
        //}

        //bool Guardar(V elemento);

        #region Escribir formato TXT
        public bool Guardar(Producto elemento)
        {
            try
            {
                string path = string.Format("{0}", this.pathArchivos);

                StreamWriter sw = new StreamWriter(path, true);//esto ya verifica si el archivo existe, si existe agrega los datos, sino lo crea.

                sw.WriteLine(elemento.Mostrar());
                sw.Close();
                return true;
            }
            catch (Exception)
            {

                throw new ArchivoException("No se pudo guardar");
            }
            //return false;
        }
        #endregion
        #region Leer Formato TXT
        //T Leer(String path);
        public string Leer(string path)
        {
            string datosRecibidos = "";
            try
            {
                bool fileExist = File.Exists(path);

                if (fileExist)
                {
                    StreamReader file = new StreamReader(path);
                    datosRecibidos = file.ReadToEnd();
                    file.Close();
                    return datosRecibidos;

                }
                datosRecibidos = "";

                return datosRecibidos;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                datosRecibidos = "";
                throw new ArchivoException("No se pudo leer");
            }
        }
        #endregion
    }
}
