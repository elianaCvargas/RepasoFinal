﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Pedido
    {
        private List<Producto> productos;

        public List<Producto> Productos { get { return this.productos; } set { this.productos = value; } }

        public Pedido()
        {
            this.productos = new List<Producto>();
        }

        //producto es el tipo de objeto que tiene que devolver , en este caso (producto)
        public Producto this[int i]
        {
            get { return productos[i]; }

        }

        public void FabricarPedido()
        {
            foreach (var item in productos)
            {
                Thread.Sleep(1000);
                item.Elaborar();
            }
        }

        public static implicit operator string(Pedido p)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in p.productos)
            {
                sb.AppendFormat("Muestro datos de los productos: {0}\r\n", item.Mostrar()); 
            }

            return sb.ToString();
        }

        //El operador + agregara un producto al pedido teniendo en cuenta que cada pedido puede
        //contener un máximo de 5 productos. (Sólo primer parcial y final: Adicionalmente validar las
        //dimensiones del producto antes de agregarlo al pedido).
        public static Pedido operator +(Pedido pedido, Producto producto)
        {
            if (pedido.productos.Count < 6)
            {
                if (producto.ValidarDimensiones())
                {
                    pedido.productos.Add(producto);
                    return pedido;
                }
                else {
                    return pedido;
                }
                
            }
            else {
                return pedido;
            }          
        }

        ///// <summary>
        ///// Dos productos son distintos si su código de barras es distinto
        ///// </summary>
        ///// <param name="v1"></param>
        ///// <param name="v2"></param>
        ///// <returns></returns>
        //public static bool operator ==(Pedido pedido, Producto producto)
        //{
        //    //if (v1._codigoDeBarras == v2._codigoDeBarras)
        //    //    return true;
        //    //return false;
        //}
        ///// <summary>
        ///// Dos productos son distintos si su código de barras es distinto
        ///// </summary>
        ///// <param name="v1"></param>
        ///// <param name="v2"></param>
        ///// <returns></returns>
        //public static bool operator !=(Pedido pedido, Producto v2)
        //{
        //    //return !(v1._codigoDeBarras != v2._codigoDeBarras);
        //}

    }
}
