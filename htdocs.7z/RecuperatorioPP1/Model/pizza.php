<?php
     
     include_once __DIR__ . '../../Manager/exceptionManager.php';

     abstract class Tipo     
     {
          public const Molde = 0;
          public const Piedra = 1;
     }

     abstract class Sabor      
     {
          public const Muzzarella = 0;
          public const Jamon = 1;
          public const Especial = 2;
     }

class Pizza 
{
      public $id;
      public $tipo;
      
      public $sabor;
      public $cantidad;
      public $precio;
      public $imagen1;
      public $imagen2;
     function __construct($id, $tipo, $sabor, $cantidad, $precio, $imagen1, $imagen2)
     {
         
          $this->SetTipo($tipo);
          $this->cantidad = $cantidad;
          $this->precio = $precio;
          $this->imagen1 = $imagen1;
          $this->imagen2 = $imagen2;
          $this->SetSabor($sabor);
          $this->id = $id;
     }

     private function SetTipo($tipo)
     {
        $tipoToLower = strtolower($tipo);
        switch($tipo)
        {
             case "Piedra":
                $this->tipo = $tipoToLower;
                 break;
             case "Molde":
                $this->tipo = $tipoToLower;
                break;
             default:
                  ExceptionManager::MostrarExcepcion("Solo existe tipo Molde o piedra.");
                  return false;
        }
     }    

     private function SetSabor($sabor)
     {
          $saborToLower = strtolower($sabor);
          switch($sabor)
          {
               case "Muzzarella":
                  $this->sabor = $saborToLower;
                   break;
               case "Jamon":
                  $this->sabor = $saborToLower;
                  break;
               case "Especial":
                  $this->sabor = $saborToLower;
                  break;
               default: 
               ExceptionManager::MostrarExcepcion("Solo existen Sabores Muzzarella, Jamon o Especial");
               return false;
          }
     }

     public function getprecio()
     {
          return $this->precio;
     }

     public function setprecio($precio)
     {
         $this->precio = $precio;
     }
     public function getId()
     {
          return $this->id;
     }
     public function setId($id)
     {
         $this->id = $id + 1;
     }
     public function Mostrar()
     {
          return json_encode($this);
     }
     public function ToJson()
     {
          $jsonString = json_encode($this);
          return json_decode($jsonString);
     }
       
     public function validate($attributes)
     {
          $errores = "";
          $cont = 0;
          if($attributes["tipo"] == "" || $attributes["tipo"] == null)
          {
               $errores = $errores."Debe ingresar un tipo.\n";
               $cont++;
          }
          if($attributes["sabor"] == "" || $attributes["sabor"] == null)
          {
               $errores = $errores."Debe ingresar un sabor.\n";
               $cont++;
          }
          if($attributes["cantidad"] == "" || $attributes["cantidad"] == null)
          {
               $errores = $errores."Debe ingresar una cantidad.\n";
               $cont++;
          }
          if($attributes["precio"] == "" || $attributes["precio"] == null )
          {
               $errores = $errores."Debe ingresar un precio.\n";
               $cont++;
          }
     
          if($attributes['imagen1'] == "" || $attributes['imagen1'] == null)
          {
               $errores = $errores."Debe adjuntar la imagen 1.\n";
               $cont++;
          }
          if($attributes['imagen2'] == "" || $attributes['imagen2'] == null)
          {
               $errores = $errores."Debe adjuntar la imagen 2.\n";
               $cont++;
          }
          if($cont >= 1)
          {
               ExceptionManager::MostrarExcepcion("\n".$errores);
               return false;
          }
          return true;
     }

}
?>