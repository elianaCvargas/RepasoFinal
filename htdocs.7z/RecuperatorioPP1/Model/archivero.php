<?php
include_once __DIR__ . '../../Manager/exceptionManager.php';
include_once __DIR__ . './pizza.php';

class archivero
{
    public static $imageName;
    public static $encontrados = [];

    public static function GuardarArchivo($attributes, $path)
    {
        $seCreoArchivo = true;
        try {
            $jsonArray = archivero::LeerArchivo($path);
            $id = archivero::ObtenerUltimoId($jsonArray);
            $id++;
            $pizza = new Pizza($id, $attributes["tipo"], $attributes["sabor"],$attributes["cantidad"],$attributes["precio"], $attributes["imagen1"]->getClientFilename(),$attributes["imagen2"]->getClientFilename());
            $jsonData = $pizza->ToJson();
            $archivoEscritura = fopen($path, "w");
            array_push($jsonArray, $jsonData);
            fwrite($archivoEscritura, json_encode($jsonArray));
            fclose($archivoEscritura);
        } catch (Exception $e) {
            return $e->getMessage();
        }
        
        return $seCreoArchivo;
    }

    public static function  ObtenerUltimoId($jsonArray)
    {
        $id = 0;
        if($jsonArray != null)
        {
            $lastElement = end($jsonArray);
            $id = $lastElement->id;
        }
        
        return $id;
    }

    public static function  ObtenerCantidad($path)
    {
        $id = 0;
        $jsonArray = archivero::LeerArchivo($path);
        if($jsonArray != null)
        {
            $lastElement = end($jsonArray);
            $id = $lastElement->cantidad;
        }
        
        return $id;
    }
    

    public static function MostrarEncontrados($dato, $path)
    {
        $datoMinuscula = strtolower($dato);

        $allAlumnos = archivero::LeerArchivo($path);
        $alumnosEncontrados = [];
        //pregunto si existe alumno
        foreach($allAlumnos as $alumno)
        {
            $miAlumno = json_decode($alumno);
            $apellidoMinuscula = strtolower($miAlumno->apellido);
            if($apellidoMinuscula == $datoMinuscula)
            {
                 array_push($alumnosEncontrados, $miAlumno);
            }           
        }

        if(count($alumnosEncontrados) > 0)
        {
            foreach($alumnosEncontrados as $alu)
            {
                $alumno = new  Alumno($alu->nombre, $alu->apellido, $alu->email, $alu->imagen);
                echo $alumno->Mostrar()."\n";               
            }
        }
        else
        {
            return "No existe alumno con apellido ".$dato;;
        }
    }


        private static function LeerArchivo($path) 
        {
            $jsonArray = [];
            if(file_exists($path))
            {
                //Leo 
                $archivoLectura = fopen($path, "r");
                
                while(!feof($archivoLectura))
                {
                    $linea = fgets($archivoLectura);
                    $jsonArray = json_decode($linea); 
                }

                fclose($archivoLectura); 
            }
            return $jsonArray;
        }

        //Trae un objeto sin JSON mediante una key y un valor que son recibidos por parametro
        public static function BuscarUnoPorClave($tipo, $sabor, $path)
        {
            $objects = archivero::LeerArchivo($path); 
            foreach ($objects as $object) { 
                if (strtolower($object->tipo) == strtolower($tipo) &&
                 strtolower($object->sabor) == strtolower($sabor))
                { 
                    return $object; 
                }
            }
            return null;
        }

        public static function ModificarUno($idKey, $idValue, $path, $objeto)
        {
            // var_dump($objeto);
            try {
                $objects = archivero::LeerArchivo($path); //Obtiene todos los objetos sin JSON
                $rta = false;
                for ($i = 0; $i < count($objects); $i++) { //recorre cada uno de esos objetos
                    if ($objects[$i]->$idKey == $idValue) { //pregunta si el objeto en la key recibida por parametro devuelve el mismo valor recibido por parametro
                        $objects[$i] = $objeto; //sobreescribe al objeto que estaba en esa posicion del array con el nuevo objeto recibido por parametro
                        $rta = true;
                        break;
                    }
                }
                if($rta === true) //si se sobreescribio correctamente el objeto ya modificado en $objects
                {
                    $archivo = fopen($path, "w"); // abro el archivo en modo escritura
                    return fwrite($archivo, json_encode($objects)); //piso el archivo con mi nuevo array con JSON
                }
                else{
                    return $rta;
                }
            } catch (Exception $e) {
                throw new Exception("No se pudo modificar", 0, $e);
            } finally {
                fclose($archivo);
            }

        }
         
    public static function  GuargarImagen($fileName, $file)
    {
        try 
        {
            $upload_path = __DIR__ . "../../images/pizzas/";
            $extension = pathInfo($fileName, PATHINFO_EXTENSION); // obtiene la extension de la foto recibida por parametro
            $name = pathInfo($fileName, PATHINFO_FILENAME); // obtiene la extension de la foto recibida por parametro
            $ficheros  = scandir($upload_path); 
            $actualName = $fileName;
            $contador = 1;
            while(in_array($actualName, $ficheros))
            {
                $actualName = $name."(".$contador.")".".".$extension;
                $contador ++;
            }
            archivero::$imageName = $actualName;
            $file->moveTo($upload_path."/".$actualName);
        } catch (\Throwable $th) {
            ExceptionManager::MostrarExcepcion("\n".$th->msgfmt_get_error_message);
        }
    }
}

?>