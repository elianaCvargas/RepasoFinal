﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;


namespace TestDao
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductoA pa = new ProductoA("pa", 10, Material.Alumino);
            ProductoA pA = new ProductoA("ptest7", 20, Material.Caucho);
            ProductoB pb = new ProductoB("pb", 15, 20, 10);

          //  ProductoDAO.GuardarProducto(pa);
         //  ProductoDAO.GuardarProducto(pb);

            List<Producto> p =  ProductoDAO.ObtenerProducto();
            foreach (var item in p)
            {
                Console.WriteLine(item.Descripcion.ToString());
            }

         //   bool modify = ProductoDAO.ModificarEmpresa(pA, 4);
            bool delete = ProductoDAO.Eliminar(pb, 8);

            foreach (var item in p)
            {
                Console.WriteLine(item.Descripcion.ToString());
            }
            Console.ReadKey();
            
        }
    }
}
