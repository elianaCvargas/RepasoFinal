﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Pedido
    {
        #region Fields
        List<Producto> productos;
        #endregion

        #region Properties
        public List<Producto> Productos
        {
            get { return this.productos; }
            set { this.productos = value; }
        }
        #endregion

        #region Methods
        public Pedido()
        {
            this.productos = new List<Producto>();
        }
        //FabricarPedido recorrerá la lista de productos,
        //por cada uno simular un retardo de 1 segundo y luego elaborar el producto. 
        public void FabricarPedido()
        {
            foreach (Producto item in productos)
            {
                Thread.Sleep(1000);
                item.Elaborar();

            }
        }


        public static Pedido operator +(Pedido pedido, Producto p )
        {
            if (pedido.productos != null)
            {
                foreach (Producto item in pedido.productos)
                {
                    if (item is ProductoA && item == p)
                    {
                        return pedido;
                    }
                    
                }
                if (pedido.productos.Count < 6)
                {
                    pedido.productos.Add(p);
                }
                
                
            }
            return pedido;
        }

        #endregion

    }
}
