﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   
    public static class ArchivosBinario
    {

        #region Serializar
        public static bool Guardar(string nombreArchivo, Producto p)
        {
            try
            {
                ProductoA pA = null;
                if (p is ProductoA)
                {
                    pA = (ProductoA)p;
                    FileStream fs;  	  //Objeto que escribirá en binario.
                    BinaryFormatter ser;  //Objeto que serializará.

                    fs = new FileStream(nombreArchivo, FileMode.Create);
                    //Se indica ubicación del archivo binario y el modo.
                    ser = new BinaryFormatter();
                    //Se crea el objeto serializador.
                    ser.Serialize(fs, pA);
                    //Serializa el objeto p en el archivo contenido en fs.
                    fs.Close();
                    return true;
                    //Se cierra el objeto fs.
                }
                //Objeto a serializar.

                return false;
            }
            catch (Exception)
            {

                throw;
            }

        } 
        #endregion

        #region Deserializar
        public static Producto Deserializar(string nombreArchivo)
        {
            Producto aux = new ProductoA();
            try
            {
                //Objeto que alojará los datos
                //contenidos en el archivo binario.
                FileStream fs;                  //Objeto que leerá en binario.
                BinaryFormatter ser;      //Objeto que Deserializará.

                fs = new FileStream(nombreArchivo, FileMode.Open);
                //Se indica ubicación del archivo binario y el modo.
                ser = new BinaryFormatter();
                //Se crea el objeto deserializador.
                aux = (ProductoA)ser.Deserialize(fs);
                //Deserializa el archivo contenido en fs, lo guarda 
                //en aux.
                fs.Close();
                return aux;
            }
            catch (Exception)
            {

                throw;
            }


        } 
        #endregion

    }
}
