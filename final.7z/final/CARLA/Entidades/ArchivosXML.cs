﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    public static class ArchivosXML
    {


        #region Escribir
        public static bool Guardar(string nombre, Producto p)
        {
            try
            {
                if (p is ProductoA)
                {
                    ProductoA pA = (ProductoA)p;
                    XmlTextWriter xw = new XmlTextWriter(nombre, Encoding.UTF8);
                    XmlSerializer ser = new XmlSerializer(typeof(ProductoA));
                    ser.Serialize(xw, pA);
                    xw.Close();
                    return true;

                }
                return false;
            }
            catch (Exception e)
            {
                // throw new ErrorArchivoException("Error al guardar el archivo", e);
                return false;
            }
        } 
        #endregion

        #region Leer
        public static Producto LeerXML(string nombreArchivo)
        {
            ProductoA votacion = new ProductoA();
            try
            {
                //ProductoA votacion = new ProductoA();
                XmlTextReader xTxtReader = new XmlTextReader(nombreArchivo);
                XmlSerializer xs = new XmlSerializer(typeof(ProductoA));
                votacion = (ProductoA)xs.Deserialize(xTxtReader);
                xTxtReader.Close();
                return votacion;
            }
            catch (Exception e)
            {
                // throw new ErrorArchivoException("Error al leer el archivo", e);
                return votacion;
            }
        } 
        #endregion



    }
}
