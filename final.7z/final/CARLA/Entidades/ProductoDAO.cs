﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public static class ProductoDAO
    {
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static ProductoDAO()
        {
            conexion = new SqlConnection(Properties.Settings.Default.cadenaConexion);
            // CREO UN OBJETO SQLCOMMAND
            comando = new SqlCommand();
            // INDICO EL TIPO DE COMANDO
            comando.CommandType = System.Data.CommandType.Text;
            // ESTABLEZCO LA CONEXION
            comando.Connection = conexion;
        }
        #region Insert
        public static bool GuardarProducto(Producto p)
        {  
            ProductoA pA = null;
            ProductoB pB = null;
            string sql = "";
            if (p is ProductoA)
            {
                pA = (ProductoA)p;
                sql = "INSERT INTO Productos (descripcion,tipo,diametro, material) VALUES('" + pA.Descripcion.ToString() + "'," +"'A',"+ "'" + pA.Diametro + "'," +"'"+pA.Material.ToString()+"'"+")";          
            }
            if (p is ProductoB)
            {
                pB = (ProductoB)p;
                sql = string.Format( "INSERT INTO Productos (descripcion,tipo, largo, alto, ancho) VALUES('{0}','B','{1}','{2}', {3})" ,pB.Descripcion, pB.Alto, pB.Ancho, pB.Largo);
            }
            try
            {
                comando.CommandText = sql;
                conexion.Open();
                comando.ExecuteNonQuery();                
            }
            catch (Exception e)
            {

                return false;
            }
            finally
            {
                   conexion.Close();
            }
            return true;
        }
        #endregion
        #region Select
        public static List<Producto> ObtenerProducto()
        {
            bool TodoOk = false;
            List<Producto> lista = new List<Producto>();
            Producto p = null;
            try
            {
                ProductoDAO.comando.CommandText = "SELECT * FROM Productos";
                ProductoDAO.conexion.Open();
                SqlDataReader oDr = ProductoDAO.comando.ExecuteReader();

                while (oDr.Read())
                {
                    string tipo = oDr["tipo"].ToString();
                    if (tipo == "A")
                    {
                        Material mat = Material.Alumino;
                        switch (oDr["material"].ToString())
                        {
                            case "Plastico":
                                mat = Material.Plastico;
                                break;
                            case "Aluminio":
                                mat = Material.Alumino;
                                break;
                            case "Caucho":
                                mat = Material.Caucho;
                                break;
                        }
                        p = new ProductoA(oDr["descripcion"].ToString(), short.Parse(oDr["diametro"].ToString()), mat);
                        lista.Add(p);
                    }
                    else
                    {
                        p = new ProductoB(oDr["descripcion"].ToString(), short.Parse(oDr["largo"].ToString()), short.Parse(oDr["ancho"].ToString()), short.Parse(oDr["alto"].ToString()));
                        lista.Add(p);
                    }


                }
                TodoOk = true;
                oDr.Close();


            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
            }
            finally
            {
                if (TodoOk)
                    ProductoDAO.conexion.Close();
            }
            return lista;
        }
        #endregion
        #region Delete
        public static bool Eliminar(Producto p, int id)
        {

            string sql =string.Format ( "DELETE  FROM Productos WHERE id = {0}" , id);

            return EjecutarNonQuery(sql);
        }
        #endregion
        #region Update
        public static bool ModificarEmpresa(Producto p, int id)
        {
            ProductoA pATest = null;
            if (p is ProductoA)
	        {
		        pATest = (ProductoA)p;
	        }
            int idTest = id;
            //string sql = "UPDATE Empresas SET descripcion = '" + p.Descripcion + "', direccion = '";
            //sql = sql + e.Direccion + "', ganancias = " + e.Ganancias.ToString().Replace(",", ".") + " WHERE id = " + e.ID.ToString();
            string sql = string.Format("UPDATE Productos SET descripcion = '{0}', tipo = '{1}', diametro = {2}, material = '{3}' where id={4};",pATest.Descripcion.ToString(), 'A',pATest.Diametro, pATest.Material.ToString(), idTest);
            return EjecutarNonQuery(sql);
        }
        #endregion

        private static bool EjecutarNonQuery(string sql)
        {
            bool todoOk = false;
            try
            {
                // LE PASO LA INSTRUCCION SQL
                ProductoDAO.comando.CommandText = sql;

                // ABRO LA CONEXION A LA BD
                ProductoDAO.conexion.Open();

                // EJECUTO EL COMMAND
                ProductoDAO.comando.ExecuteNonQuery();

                todoOk = true;
            }
            catch (Exception e)
            {
                todoOk = false;
            }
            finally
            {
                if (todoOk)
                    ProductoDAO.conexion.Close();
            }
            return todoOk;
        }
    }
}
