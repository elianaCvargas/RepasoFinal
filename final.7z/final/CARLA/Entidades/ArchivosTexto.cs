﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class ArchivosTexto
    {
        #region Escribir formato TXT
        public static bool EscribirTxt(this string textoAEscribir, string nombreArchivo)
        {
            try
            {
                //obtenemos el path del directorio al cual queremos guardar
                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + nombreArchivo;
                //bool fileExist = File.Exists(path);
                //if (!fileExist)
                //{
                StreamWriter sw = new StreamWriter(path, true);//esto ya verifica si el archivo existe, si existe agrega los datos, sino lo crea.
                string text = string.Format("{0}", textoAEscribir);
                sw.WriteLine(textoAEscribir);
                sw.Close();
                return true;
                //}

            }
            catch (Exception ex)
            {

                throw ex;

            }
            //return false;
        }
        #endregion
        #region Leer Formato TXT
        public static bool Leer(this string nombreArchivo, out string datosRecibidos)
        {

            try
            {
                string secuenciaMasNombreTexto = string.Format("\x5c{0}", nombreArchivo);

                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + secuenciaMasNombreTexto;
                //string pathReal = "C:\nUsers\nCarlaEliana\nDesktop\nArchivoTxt";
                bool fileExist = File.Exists(nombreArchivo);
                //fileexist da true porque el archvo esta en el directorio por defecto
                if (fileExist)
                {
                    StreamReader file = new StreamReader(nombreArchivo);
                    datosRecibidos = file.ReadToEnd();
                    return true;

                }
                datosRecibidos = "";
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                datosRecibidos = "";
                return false;

            }
        }
        #endregion


        //Otros:
        //Environment.CurrentDirectory;
        // devuelve el directorio or default al cual seran guardados los archivos (C:\\Users\\CarlaEliana\\Desktop\\final\\CARLA\\TestArchivos\\bin\\Debug)

    }
}
