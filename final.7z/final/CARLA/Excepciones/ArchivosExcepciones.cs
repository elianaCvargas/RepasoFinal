﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    class ArchivosExcepciones: Exception
    {

        public ArchivosExcepciones(string mensaje, Exception inner)
            :base(mensaje, inner)
        {

        }
        public ArchivosExcepciones(string mensaje)
            :this(mensaje,null)
        {

        }
    }
}
