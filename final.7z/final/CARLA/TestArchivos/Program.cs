﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;


namespace TestArchivos
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Prueba Escribir TXT
            //string texto = "Carla Eliana Vargas";
            //string nombreArchivo = "ArchivoTxt";
            //ArchivosTexto.EscribirTxt(texto, nombreArchivo); 
            #endregion
            #region Prueba Leer TXT
            //string datos = "";
            //string nombreArchivo = "ArchivoTxt";
            //ArchivosTexto.Leer(nombreArchivo, out datos);
            //Console.WriteLine(datos); 
            #endregion

            #region Prueba Escribir XML
            ProductoA pa = new ProductoA("pa", 10, Material.Alumino);
            //ProductoA pA = new ProductoA("ptest7", 20, Material.Caucho);
            //ProductoB pb = new ProductoB("pb", 15, 20, 10);
            //ArchivosXML.Guardar("TextoXML", pA); 
            #endregion

            
            //Producto p = ArchivosXML.LeerXML("TextoXML");

            //ArchivosBinario.Guardar("BinarioTexto", pa);
            Producto p = ArchivosBinario.Deserializar("BinarioTexto");


            Console.ReadKey();


        }
    }
}
