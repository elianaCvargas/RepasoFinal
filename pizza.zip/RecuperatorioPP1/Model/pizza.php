<?php
     
     include_once __DIR__ . '../../Manager/exceptionManager.php';

     abstract class Tipo     
     {
          public const Molde = 0;
          public const Piedra = 1;
     }

     abstract class Sabor      
     {
          public const Muzzarella = 0;
          public const Jamon = 1;
          public const Especial = 2;
     }

     class Pizza 
     {
        public $id;
        public $tipo;
        
        public $sabor;
        public $cantidad;
        public $precio;
        public $imagen1;
        public $imagen2;

       function __construct($id, $tipo, $sabor, $cantidad, $precio, $imagen1, $imagen2)
       {
           
            $this->SetTipo($tipo);
            $this->cantidad = $cantidad;
            $this->precio = $precio;
            $this->imagen1 = $imagen1;
            $this->imagen2 = $imagen2;
            $this->SetSabor($sabor);


       }

       private function SetTipo($tipo)
       {
          switch($tipo)
          {
               case "Piedra":
                  $this->tipo = Tipo::Piedra;
                   break;
               case "Molde":
                  $this->tipo = Tipo::Molde;
                  break;
               default:
                    ExceptionManager::MostrarExcepcion("Solo existe tipo Molde o piedra.");
          }
       }

       private function SetSabor($sabor)
       {
            switch($sabor)
            {
                 case "Muzzarella":
                    $this->sabor = Sabor::Muzzarella;
                     break;
                 case "Jamon":
                    $this->sabor = Sabor::Jamon;
                    break;
                 case "Especial":
                    $this->sabor = Sabor::Especial;
                    break;
                 default: 
                 ExceptionManager::MostrarExcepcion("Solo existen Sabores Muzzarella, Jamon o Especial");
            }
       }

       public function getprecio()
       {
            return $this->precio;
       }
    
       public function setprecio($precio)
       {
           $this->precio = $precio;
       }

       public function getId()
       {
            return $this->id;
       }
    
       public function setIdString($id)
       {
           $this->idString = $id."";
       }

       public function setId($id)
       {
           $this->id = $id + 1;
       }

       public function Mostrar()
       {
           
            return json_encode($this);
       }
       public function ToJson()
       {
            $jsonString = json_encode($this);
            return json_decode($jsonString);
       }
       
          public function validate($attributes)
          {
               $errores = "";
               $cont = 0;
               if($attributes["tipo"] == "" || $attributes["tipo"] == null)
               {
                    $errores = $errores."Debe ingresar un tipo.\n";
                    $cont++;
               }

               if($attributes["sabor"] == "" || $attributes["sabor"] == null)
               {
                    $errores = $errores."Debe ingresar un sabor.\n";
                    $cont++;
               }

               if($attributes["cantidad"] == "" || $attributes["cantidad"] == null)
               {
                    $errores = $errores."Debe ingresar una cantidad.\n";
                    $cont++;
               }

               if($attributes["precio"] == "" || $attributes["precio"] == null )
               {
                    $errores = $errores."Debe ingresar un precio.\n";
                    $cont++;
               }
          
               if($cont >= 1)
               {
                    ExceptionManager::MostrarExcepcion("\n".$errores);
                    return false;
               }
               return true;
          }

     }
?>