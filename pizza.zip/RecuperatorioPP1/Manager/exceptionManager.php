<?php
class ExceptionManager
{
    public static function MostrarExcepcion($error)
    {
        echo "Se ha producido el siguiente error: ".$error."\n";
    }

}

?>