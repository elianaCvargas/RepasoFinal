<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
include_once __DIR__ . '/Api/pizzaApi.php';

$config ['displayErrorDetails'] = true;
$config ['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->group('/pizza', function() 
{
    $this->post('/', pizzaApi::class . ':cargarUno');
    $this->get('/', pizzaApi::class. ':ObtenerCantidadProducto');
});

$app -> run();


