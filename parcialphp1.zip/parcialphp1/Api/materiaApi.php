<?php
include_once __DIR__ . '../../Model/materia.php';
include_once __DIR__ . '../../Model/archivero.php';

class materiaApi
{
    private $arrayDeParametros;
    public function cargarMateria($request, $response, $args){
        $this->arrayDeParametros = $request->getParsedBody();  
         if(!isset($this->arrayDeParametros['nombre']) || !isset($this->arrayDeParametros['codigo']) 
          || !isset($this->arrayDeParametros['cupo']) || !isset($this->arrayDeParametros['aula']))
        {
            return "Falta definir parametros de entrada";
        }

        $attributes = [
            "nombre" => $this->arrayDeParametros['nombre'],
            "codigo" => $this->arrayDeParametros['codigo'],
            "cupo" => $this->arrayDeParametros['cupo'],
            "aula" => $this->arrayDeParametros['aula'],
        ];

        materia::validate($attributes);
        
        $materiaBuscada = archivero::BuscarUnoPorCodigo($attributes["codigo"], "materia.txt");  
             
        if($materiaBuscada == null)
        {
            $seCreoArchivo = archivero::GuardarArchivo($attributes, "materia.txt");                    
            $mensaje = $seCreoArchivo ? "Se generó el archivo...\n" : "Something happened.";    
            return $response->getbody()->write($mensaje);
        }
        else{
            return "La materia ya existe";
        }
    }

    public function consultarmateria($request, $response, $args)
    {
        $params = $request->getQueryParams(); 
        $materiaBuscado = archivero::BuscarPorcodigo($params['codigo'], "materia.txt");
        if($materiaBuscado != null)
        {
            foreach($materiaBuscado as $materia)
            {
                echo $materia->nombre." ".$materia->codigo." ".$materia->cupo."\n";
            }
             return $materiaBuscado;
        }
        else
        {
            return "No se encontró coincidencias.";
        }
    }
    

    private function GuardarImagenes($img1, $img2)
    {
        $fullName1 = $img1->getClientFilename();
        $fullName2 = $img2->getClientFilename();
        Archivero::GuargarImagen($fullName1, $img1);
        Archivero::GuargarImagen($fullName2, $img2);
    }

    private function GuardarImagen($img1)
    {
        $fullName1 = $img1->getClientFilename();
        Archivero::GuargarImagen($fullName1, $img1);
    }



}