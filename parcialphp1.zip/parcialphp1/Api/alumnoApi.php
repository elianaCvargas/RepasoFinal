<?php
include_once __DIR__ . '../../Model/alumno.php';
include_once __DIR__ . '../../Model/archivero.php';

class alumnoApi
{
    private $arrayDeParametros;
    public function cargarAlumno($request, $response, $args){
        $this->arrayDeParametros = $request->getParsedBody();  
        $archivos = $request->getUploadedFiles();  
         if(!isset($this->arrayDeParametros['nombre']) || !isset($this->arrayDeParametros['apellido']) 
          || !isset($this->arrayDeParametros['email']) || !isset($archivos['imagen1'])
         )
        {
            return "Falta definir parametros de entrada";
        }

        $attributes = [
            "nombre" => $this->arrayDeParametros['nombre'],
            "apellido" => $this->arrayDeParametros['apellido'],
            "email" => $this->arrayDeParametros['email'],
            "imagen1" => $archivos['imagen1'],
        ];

        alumno::validate($attributes);
        
        $alumnoBuscada = archivero::BuscarUnoPorEmail($attributes["email"], "alumno.txt");  
             
        if($alumnoBuscada == null)
        {
            $this::GuardarImagen($attributes["imagen1"]);
            $seCreoArchivo = archivero::GuardarArchivo($attributes, "alumno.txt");                    
            $mensaje = $seCreoArchivo ? "Se generó el archivo...\n" : "Something happened.";    
            return $response->getbody()->write($mensaje);
        }
        else{
            return "La alumno ya existe";
        }
    }

    public function consultarAlumno($request, $response, $args)
    {
        $params = $request->getQueryParams(); 
        $alumnoBuscado = archivero::BuscarPorapellido($params['apellido'], "alumno.txt");
        if($alumnoBuscado != null)
        {
            foreach($alumnoBuscado as $alumno)
            {
                echo $alumno->nombre." ".$alumno->apellido." ".$alumno->email."\n";
            }
             return $alumnoBuscado;
        }
        else
        {
            return "No se encontró coincidencias.";
        }
    }
    

    private function GuardarImagenes($img1, $img2)
    {
        $fullName1 = $img1->getClientFilename();
        $fullName2 = $img2->getClientFilename();
        Archivero::GuargarImagen($fullName1, $img1);
        Archivero::GuargarImagen($fullName2, $img2);
    }

    private function GuardarImagen($img1)
    {
        $fullName1 = $img1->getClientFilename();
        Archivero::GuargarImagen($fullName1, $img1);
    }

    

//     public function modificarUno($request, $response, $args){ 
//         $rta = false;
       
//         $parametros = $request->getParsedBody();
//         $archivos = $request->getUploadedFiles();

//         // var_dump($archivos);
//         var_dump($parametros);

//         $alumnoAModificar = archivero::BuscarUnoPorClaveInsensityveCase("email", $parametros["email"], "Alumno.txt");  
//         //var_dump($alu);
//         //puede ir en un controller
//         if(!is_null($alumnoAModificar))
//         {
//             $rta == true;
//                 /// Me guardo el valor actual de todas la claves del usuario, si el usuario deseará modificarlas, se pisaran.
//                 $nombreAux = $alumnoAModificar->nombre;
//                 $apellidoAux = $alumnoAModificar->apellido;
//                 $fotoAux = $alumnoAModificar->imagen;
//                 $idAux = $alumnoAModificar->id;

//                 //pregunta si en el POST que se recibio por parametro contiene la key "apellido" para verificar si es lo que se quiere modificar y ademas pregunta si el apellido del alumno obtenido por email es distinto del apellido que hay en el POST
//                 if (array_key_exists("apellido", $parametros) && $apellidoAux != $parametros["apellido"]) { 
//                     $apellidoAux = $parametros["apellido"]; //pisa el apellido del alumno obtenido con el apellido recibido en POST
//                 }
//                 //pregunta si en el POST que se recibio por parametro contiene la key "nombre" para verificar si es lo que se quiere modificar y ademas pregunta si el nombre del alumno obtenido por email es distinto del nombre que hay en el POST
//                 if (array_key_exists("nombre", $parametros) && $nombreAux != $parametros["nombre"]) {
//                     $nombreAux = $parametros["nombre"];//pisa el nombre del alumno obtenido con el nombre recibido en POST
//                 }
//                 if (array_key_exists("foto", $archivos)) {
//                     $fechaBkp = date("d-m-Y_H_i");// Me guardo la hora actual
//                     $array = explode(".", $alumnoAModificar->foto); //transformo en un array todo lo que este separado por un punto
//                     $rutaParaBkp = "./imagenes/backUpFotos/" . 
//                     $alumnoAModificar->apellido . $fechaBkp . "." . end($array);//Genero la ruta para almacenar la foto de backup
//                     //Backup Imagen
//                     rename($alumnoAModificar->foto, $rutaParaBkp);// Hago backup de la foto
//                     //Modificacion
//                     $tmpName = $foto->getClientFilename();
//                     $extension = pathinfo($tmpName, PATHINFO_EXTENSION);
//                     $fotoAux = "./imagenes/" . $parametros["email"] . "." . $extension; // Cambio el nombre de la foto y coloco email.extension
//                     $foto->moveTo($fotoAux);
//                 } 
//                 $alumnoAux = new Alumno($nombreAux, $apellidoAux, $parametros["email"], $fotoAux); //se crea un nuevo alumno con los datos ya modificados
//                 $alumnoAux->id = $idAux;
// // var_dump($alumnoAux->id );
//                 $rta = archivero::modificarUno("email", $parametros["email"], "Alumno.txt", $alumnoAux);
//                 if($rta)
//                 {
//                     echo "Modificacion realizada";
//                 }
//                 else{
//                     echo "No se pudo realizar la modificacion";
//                 }
//         }
//         else{
//             echo "No se encontro el alumno";
//         }
        
        
//     }

//     public function borrarUno($request, $response, $args){ 
//         return $response->getbody()->write("Hello world DELETE");
//     }


}