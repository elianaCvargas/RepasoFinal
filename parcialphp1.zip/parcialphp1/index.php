<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
include_once __DIR__ . '/Api/alumnoApi.php';
include_once __DIR__ . '/Api/materiaApi.php';


$config ['displayErrorDetails'] = true;
$config ['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->group('/alumno', function() 
{
    $this->post('/', alumnoApi::class . ':cargarAlumno');
    $this->get('/', alumnoApi::class. ':consultarAlumno');
});

$app->group('/materia', function() 
{
    $this->post('/', materiaApi::class . ':cargarMateria');
    //$this->get('/', materiaApi::class. ':consultarAlumno');
});
$app -> run();


