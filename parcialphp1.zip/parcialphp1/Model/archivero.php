<?php
include_once __DIR__ . '../../Manager/exceptionManager.php';
include_once __DIR__ . './alumno.php';
include_once __DIR__ . './materia.php';


class archivero
{
    public static $imageName;
    public static $encontrados = [];

    public static function GuardarArchivo($attributes, $path)
    {
        $seCreoArchivo = true;
        try {
            $jsonData;
            $jsonArray = archivero::LeerArchivo($path);
            $id = archivero::ObtenerUltimoId($jsonArray);
            $id++;

            if($path == "alumno.txt")
            {
                $jsonData = archivero::cargarAlumno($attributes, $id);
            }
            else
            {
                $jsonData = archivero::cargarMateria($attributes, $id);
            }
            $archivoEscritura = fopen($path, "w");
            array_push($jsonArray, $jsonData);
            fwrite($archivoEscritura, json_encode($jsonArray));
            fclose($archivoEscritura);
        } catch (Exception $e) {
            return $e->getMessage();
        }
        
        return $seCreoArchivo;
    }

    public static function  cargarAlumno($attributes, $id)
    {
        $alumno = new Alumno($id, $attributes["nombre"], $attributes["apellido"],$attributes["email"], $attributes["imagen1"]->getClientFilename());
        $jsonData = $alumno->ToJson();
        return $jsonData;
    }

    public static function  cargarMateria($attributes, $id)
    {
        $materia = new Materia($id, $attributes["nombre"], $attributes["codigo"],$attributes["cupo"], $attributes["aula"]);
        $jsonData = $materia->ToJson();
        return $jsonData;
    }

    public static function  ObtenerUltimoId($jsonArray)
    {
        $id = 0;
        if($jsonArray != null)
        {
            $lastElement = end($jsonArray);
            $id = $lastElement->id;
        }
        
        return $id;
    }

    public static function  ObtenerCantidad($path)
    {
        $id = 0;
        $jsonArray = archivero::LeerArchivo($path);
        if($jsonArray != null)
        {
            $lastElement = end($jsonArray);
            $id = $lastElement->cantidad;
        }
        
        return $id;
    }
    

    public static function BuscarPorapellido($apellido, $path)
    {
        $allAlumnos = archivero::LeerArchivo($path);
        $alumnosEncontrados = [];
        foreach($allAlumnos as $alumno)
        {
            if(strtolower($apellido) == strtolower($alumno->apellido))
            {
                 array_push($alumnosEncontrados, $alumno);
            }           
        }

        return $alumnosEncontrados;       
    }


        private static function LeerArchivo($path) 
        {
            $jsonArray = [];
            if(file_exists($path))
            {
                //Leo 
                $archivoLectura = fopen($path, "r");
                
                while(!feof($archivoLectura))
                {
                    $linea = fgets($archivoLectura);
                    $jsonArray = json_decode($linea); 
                }

                fclose($archivoLectura); 
            }
            return $jsonArray;
        }

        //Trae un objeto sin JSON mediante una key y un valor que son recibidos por parametro
        public static function BuscarUnoPorClave($tipo, $sabor, $path)
        {
            $objects = archivero::LeerArchivo($path); 
            foreach ($objects as $object) { 
                if (strtolower($object->tipo) == strtolower($tipo) &&
                 strtolower($object->sabor) == strtolower($sabor))
                { 
                    return $object; 
                }
            }
            return null;
        }

        public static function BuscarUnoPorCodigo($codigo, $path)
        {
            $objects = archivero::LeerArchivo($path); 
            foreach ($objects as $object) { 
                if (strtolower($object->codigo) == strtolower($codigo))
                { 
                    return $object; 
                }
            }
            return null;
        }

        public static function BuscarUnoPorEmail($email, $path)
        {
            $objects = archivero::LeerArchivo($path); 
            foreach ($objects as $object) { 
                if (strtolower($object->email) == strtolower($email))
                { 
                    return $object; 
                }
            }
            return null;
        }

        public static function ModificarUno($idKey, $idValue, $path, $objeto)
        {
            // var_dump($objeto);
            try {
                $objects = archivero::LeerArchivo($path); //Obtiene todos los objetos sin JSON
                $rta = false;
                for ($i = 0; $i < count($objects); $i++) { //recorre cada uno de esos objetos
                    if ($objects[$i]->$idKey == $idValue) { //pregunta si el objeto en la key recibida por parametro devuelve el mismo valor recibido por parametro
                        $objects[$i] = $objeto; //sobreescribe al objeto que estaba en esa posicion del array con el nuevo objeto recibido por parametro
                        $rta = true;
                        break;
                    }
                }
                if($rta === true) //si se sobreescribio correctamente el objeto ya modificado en $objects
                {
                    $archivo = fopen($path, "w"); // abro el archivo en modo escritura
                    return fwrite($archivo, json_encode($objects)); //piso el archivo con mi nuevo array con JSON
                }
                else{
                    return $rta;
                }
            } catch (Exception $e) {
                throw new Exception("No se pudo modificar", 0, $e);
            } finally {
                fclose($archivo);
            }

        }
         
    public static function  GuargarImagen($fileName, $file)
    {
        try 
        {
            $upload_path = __DIR__ . "../../images/alumnos/";
            $extension = pathInfo($fileName, PATHINFO_EXTENSION); // obtiene la extension de la foto recibida por parametro
            $name = pathInfo($fileName, PATHINFO_FILENAME); // obtiene la extension de la foto recibida por parametro
            $ficheros  = scandir($upload_path); 
            $actualName = $fileName;
            $contador = 1;
            while(in_array($actualName, $ficheros))
            {
                $actualName = $name."(".$contador.")".".".$extension;
                $contador ++;
            }
            archivero::$imageName = $actualName;
            $file->moveTo($upload_path."/".$actualName);
        } catch (\Throwable $th) {
            ExceptionManager::MostrarExcepcion("\n".$th->msgfmt_get_error_message);
        }
    }
}

?>