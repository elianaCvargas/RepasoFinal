
<?php
     
     include_once __DIR__ . '../../Manager/exceptionManager.php';

class Materia 
{
      public $id;
      public $nombre;
      public $codigo;   
      public $cupo;
      public $aula;

     function __construct($id, $nombre, $codigo, $cupo, $aula)
     {
         
          $this->nombre = $nombre;
          $this->cupo = $cupo;
          $this->aula = $aula;
          $this->codigo = $codigo;
          $this->id = $id;
     }

     public function getaula()
     {
          return $this->aula;
     }

     public function setaula($aula)
     {
         $this->aula = $aula;
     }
     public function getId()
     {
          return $this->id;
     }
     public function setId($id)
     {
         $this->id = $id + 1;
     }
     public function Mostrar()
     {
          return json_encode($this);
     }
     public function ToJson()
     {
          $jsonString = json_encode($this);
          return json_decode($jsonString);
     }
       
     public function validate($attributes)
     {
          $errores = "";
          $cont = 0;
          if($attributes["nombre"] == "" || $attributes["nombre"] == null)
          {
               $errores = $errores."Debe ingresar un nombre.\n";
               $cont++;
          }
          if($attributes["codigo"] == "" || $attributes["codigo"] == null)
          {
               $errores = $errores."Debe ingresar un codigo.\n";
               $cont++;
          }
          if($attributes["cupo"] == "" || $attributes["cupo"] == null)
          {
               $errores = $errores."Debe ingresar una cupo.\n";
               $cont++;
          }
          if($attributes["aula"] == "" || $attributes["aula"] == null )
          {
               $errores = $errores."Debe ingresar un aula.\n";
               $cont++;
          }
          
          if($cont >= 1)
          {
               ExceptionManager::MostrarExcepcion("\n".$errores);
               return false;
          }
          return true;
     }

}
?>