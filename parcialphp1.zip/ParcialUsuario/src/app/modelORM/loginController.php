<?php
namespace App\Models\ORM;
use App\Models\AutentificadorJWT;
use App\Models\ORM\acceso;
use App\Models\ORM\usuario;
use App\Managers\ExceptionManager;

include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';
include_once __DIR__ . '/acceso.php';
include_once __DIR__ . '/usuario.php';
include_once __DIR__ . '../../managers/ExceptionManager.php';
class loginController 
{
    public function login($request, $response, $args)
    {
        $arrayDeParametros = $request->getParsedBody();
        $datos = array(
            'clave' => $arrayDeParametros["clave"],
            'email' => $arrayDeParametros["email"], 
            'legajo' => $arrayDeParametros["legajo"]);
        
        $user = Usuario::where('clave', $arrayDeParametros["clave"])
        ->where('email', $arrayDeParametros["email"])
        ->where('legajo', $arrayDeParametros["legajo"])->first();

    //    $emailDb =  $user->email;
    //    var_dump($emailDb);
        if($user != null)
        {
            $token= AutentificadorJWT::CrearToken($datos);
            $newResponse = $response->withJson($token, 200); 
            return $newResponse;  
        }
        else 
        {
            return  ExceptionManager::MostrarExcepcion("No existe el usuario.");
        }
    }
}

?>