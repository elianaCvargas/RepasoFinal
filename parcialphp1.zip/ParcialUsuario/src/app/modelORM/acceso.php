<?php  
namespace App\Models\ORM;
 
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Managers\ExceptionManager;

include_once __DIR__ . '../../managers/ExceptionManager.php';

class acceso extends \Illuminate\Database\Eloquent\Model {  
  
   /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
        'legajo', 'email', 'clave','fechaIngreso', 'fechaEgreso'
    ];

    public function validate($attributes)
    {
        $errores = "";
        $cont = 0;
        if($attributes["legajo"] == "" || $attributes["legajo"] == null)
        {
            //ExceptionManager::MostrarExcepcion("");
            $errores = $errores."Debe ingresar un legajo.\n";
            $cont++;
        }
        else
        {
            if(intval($attributes["legajo"]) > 1000 || intval($attributes["legajo"]) < 1)
            {
                $errores = $errores."Debe ingresar un legajo entre 1 y 1000.\n";
                $cont++;
                // ExceptionManager::MostrarExcepcion("Debe ingresar un legajo entre 1 y 1000");
                // return false;
            }
        }

        if($attributes["email"] == "" || $attributes["email"] == null)
        {
            // ExceptionManager::MostrarExcepcion("Debe ingresar un email.");
            // return false;  
            $errores = $errores."Debe ingresar un email.\n";
            $cont++;
        }

        if($attributes["clave"] == "" || $attributes["clave"] == null)
        {
            // ExceptionManager::MostrarExcepcion("Debe ingresar una clave.");
            // return false;  
            $errores = $errores."Debe ingresar una clave.\n";
            $cont++;
        }

        if($attributes["tipo"] == "" || $attributes["tipo"] == null )
        {
            // ExceptionManager::MostrarExcepcion("Debe ingresar un tipo.");
            // return false;  
            
            $errores = $errores."Debe ingresar un tipo.\n";
            $cont++;
        }
        
        if($cont >= 1)
        {
            ExceptionManager::MostrarExcepcion("\n".$errores);
            return false;
        }
        return true;
    }

    public function validateImage($archivos)
    {
        if($archivos['imagen1'] == "" || $archivos['imagen1'] == null)
        {
            ExceptionManager::MostrarExcepcion("Debe adjuntar la imagen 1");
            return false;
        }

        if($archivos['imagen2'] == "" || $archivos['imagen2'] == null)
        {
            ExceptionManager::MostrarExcepcion("Debe adjuntar la imagen 2");
            return false;
        }
        
        return true;
    }
}
