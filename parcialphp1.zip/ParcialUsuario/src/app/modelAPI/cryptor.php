<?php

/**
 * Slim - a micro PHP 5 framework
 *
 * @author      Josh Lockhart <info@slimframework.com>
 * @copyright   2011 Josh Lockhart
 * @link        http://www.slimframework.com
 * @license     http://www.slimframework.com/license
 * @version     2.3.0
 * @package     Slim
 *
 * MIT LICENSE
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

namespace App\Models;
use \Slim\Interfaces\CryptInterface;

class Cryptor 
{

    public function encrypt($data, $cryptoKey)
    {
        $iv = mcrypt_create_iv(
            mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC),
            MCRYPT_DEV_URANDOM
        );
var_dump($iv);
        $encrypted = base64_encode(
            $iv .
            mcrypt_encrypt(
                MCRYPT_RIJNDAEL_128,
                hash('sha256', $cryptoKey, true),
                $data,
                MCRYPT_MODE_CBC,
                $iv
            )
        );

        return $encrypted;
    }

    public function decrypt($encrypted, $key)
    {
        $data = base64_decode($encrypted);
        $iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));
        
        $decrypted = rtrim(
            mcrypt_decrypt(
                MCRYPT_RIJNDAEL_128,
                hash('sha256', $key, true),
                substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),
                MCRYPT_MODE_CBC,
                $iv
            ),
            "\0"
        );

        return $decrypted;
    }

    protected function getHmac($data)
    {
        return hash_hmac('sha256', (string)$data, $this->key);
    }

    public function validateKeyLength($key, $module)
    {
        $keySize = strlen($key);
        $keySizeMin = 1;
        $keySizeMax = mcrypt_enc_get_key_size($module);
        $validKeySizes = mcrypt_enc_get_supported_key_sizes($module);
        if ($validKeySizes) {
            if (!in_array($keySize, $validKeySizes)) {
                throw new \InvalidArgumentException('Encryption key length must be one of: ' . implode(', ', $validKeySizes));
            }
        } else {
            if ($keySize < $keySizeMin || $keySize > $keySizeMax) {
                throw new \InvalidArgumentException(sprintf(
                    'Encryption key length must be between %s and %s, inclusive',
                    $keySizeMin,
                    $keySizeMax
                ));
            }
        }
    }
    /**
     * Check the mcrypt PHP extension is loaded
     * @throws \RuntimeException If the mcrypt PHP extension is missing
     */
    protected function checkRequirements()
    {
        if (extension_loaded('mcrypt') === false) {
            throw new \RuntimeException(sprintf(
                'The PHP mcrypt extension must be installed to use the %s encryption class.',
                __CLASS__
            ));
        }
    }
    /**
     * Throw an exception based on a provided exit code
     * @param  mixed  $code
     * @param  string $function
     * @throws \RuntimeException If there was a memory allocation problem
     * @throws \RuntimeException If there was an incorrect key length specified
     * @throws \RuntimeException If an unknown error occured
     */
    protected function throwInitError($code, $function)
    {
        switch ($code) {
            case -4:
                throw new \RuntimeException(sprintf(
                    'There was a memory allocation problem while calling %s::%s',
                    __CLASS__,
                    $function
                ));
                break;
            case -3:
                throw new \RuntimeException(sprintf(
                    'An incorrect encryption key length was used while calling %s::%s',
                    __CLASS__,
                    $function
                ));
                break;
            default:
                if (is_integer($code) && $code < 0) {
                    throw new \RuntimeException(sprintf(
                        'An unknown error was caught while calling %s::%s',
                        __CLASS__,
                        $function
                    ));
                }
                break;
        }
    }
}