<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\usuario;
use App\Models\ORM\usuarioController;
use App\Models\ORM\loginController;
use App\Models\ORM\accesoController;

include_once __DIR__ . '/../../src/app/modelORM/usuarioController.php';
include_once __DIR__ . '/../../src/app/modelORM/accesoController.php';

return function (App $app) {
    $container = $app->getContainer();

    //  $app->group('/cdORM', function () {   
         
    //     $this->get('/', function ($request, $response, $args) {
    //       //return cd::all()->toJson();
    //       $todosLosCds=cd::all();
    //       $newResponse = $response->withJson($todosLosCds, 200);  
    //       return $newResponse;
    //     });
    // });


     $app->group('/usuarioORM', function () {   

       // $this->get('/', usuarioControler::class . ':traerTodos');
        $this->post('/', usuarioController::class . ':CargarUno');
        $this->post('/login/', loginController::class . ':login');
        $this->put('/ingreso/', accesoController::class . ':ingresar');
        $this->put('/egreso/', accesoController::class . ':egresar');
        $this->get('/ingreso/', accesoController::class . ':MostrarUsuarioLoggeado');
    });

};